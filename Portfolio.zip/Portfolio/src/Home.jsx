import React from 'react'
import {Link} from 'react-router-dom';
import Projects from './Projects';

export default function Home() {
  return (
    <div>
      <div className="headings">
        <div className="text">
        <h1>Welcome to my Portfolio</h1>
        <p>Hi! I'm Muhammad Taha, a Computer Science undergraduate at Riphah International University. I'm passionate about frontend development with React.js and I'm actively seeking internship opportunities to build real-world applications.</p>
        </div>
        <div className="image">
            <img src="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8ZGV2ZWxvcGVyfGVufDB8fDB8fHww&auto=format&fit=crop&w=500&q=60" alt="Developer" />    
        </div>
      </div>
      <div className="button-container">
            <Link to = '/projects'><button className="btn">View my work</button></Link>
        </div>
    </div>
  )
}
