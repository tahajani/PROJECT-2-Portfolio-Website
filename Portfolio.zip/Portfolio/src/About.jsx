import React from 'react'

export default function About() {
  return (
    <div>
      <div className="container">
        <h1><span>About Me</span></h1>
       <p> Undergraduate Computer Science student at Riphah International University | Building practical skills through projects.
        I'm actively seeking an internship to grow as a frontend developer/engineer. I've built a portfolio to showcase my hands-on work, including projects like gemini-clone app.
        </p>
        <div className="skills">
            <h2>My Skills</h2>
            <ul>
                <li>HTML</li>
                <li>CSS</li>
                <li>JavaScript</li>
                <li>React</li>
            </ul>
        </div>
      </div>
    </div>
  )
}
