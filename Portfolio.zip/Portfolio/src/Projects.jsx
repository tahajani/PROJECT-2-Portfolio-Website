import React from 'react'
import projectimg from './assets/projectimg.png'
import w1 from './assets/w1.png'
import w2 from './assets/w2.png'
export default function Projects() {
  return (
    <div>
      <div className="header">
        <h1>My Projects</h1>
        <p>Here are some of the projects I have worked on recently.</p>
        <div className="projects">
          <marquee behavior="" direction=""><h2>Gemini Clone app</h2></marquee>
          <img src={projectimg} alt="" />
          <marquee behavior="" direction=""><h2>Single Page Weather App</h2></marquee>
          <img src={w1} alt="" />
          <img src={w2} alt="" />
        </div>
      </div>
    </div>
  )
}
