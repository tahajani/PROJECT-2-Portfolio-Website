import React from 'react'

export default function Contacts() {
  return (
    <div>
      <div className="contacts-container">
        <h1><span>Let's Connect</span></h1>
        <p>If you would like to get in touch, please feel free to reach out through any of the following methods:</p>
        <div className="contact-methods">
            <ul>
                <li>Email: taha2004work@gmail.com</li>
                <li>Phone: 03351400703</li>
                <li>LinkedIn: linkedin.com/in/muhammad-taha-5967623a4</li>
                <li>GitHub: github.com/tahajani</li>
            </ul>
        </div>
      </div>
    </div>
  )
}
